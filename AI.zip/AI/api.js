// api/chat.js
const { GoogleGenerativeAI } = require('@google/generative-ai');

// Inisialisasi Gemini dengan API Key dari environment variable
const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);

module.exports = async (req, res) => {
    // CORS untuk mengizinkan akses dari domain mana pun (optional)
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    try {
        const { message } = req.body;

        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        // Pilih model Gemini
        const model = genAI.getGenerativeModel({ 
            model: 'gemini-2.0-flash',
            systemInstruction: 'Kamu adalah asisten AI yang ramah, membantu, dan bernama Lynzxyx. Jawablah dengan bahasa Indonesia yang sopan dan informatif.'
        });

        // Kirim prompt ke Gemini
        const result = await model.generateContent(message);
        const response = await result.response;
        const text = response.text();

        res.status(200).json({ reply: text });

    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ 
            error: 'Terjadi kesalahan pada server',
            details: error.message 
        });
    }
};