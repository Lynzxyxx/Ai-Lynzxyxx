// script.js
const chatBox = document.getElementById('chatBox');
const userInput = document.getElementById('userInput');
const sendButton = document.getElementById('sendButton');
const status = document.getElementById('status');

// Enter key untuk mengirim pesan
userInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

// Fungsi untuk mengirim pesan
async function sendMessage() {
    const message = userInput.value.trim();
    if (!message) return;

    // Tampilkan pesan user
    addMessage(message, 'user');
    userInput.value = '';
    sendButton.disabled = true;
    status.textContent = 'Lynzxyx sedang mengetik...';

    // Hapus welcome message jika ada
    const welcome = document.querySelector('.welcome-message');
    if (welcome) welcome.remove();

    try {
        // Kirim request ke API backend Vercel
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: message }),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        addMessage(data.reply, 'bot');

    } catch (error) {
        console.error('Error:', error);
        addMessage('Maaf, terjadi kesalahan. Silakan coba lagi.', 'bot');
        status.textContent = '❌ Error: Gagal terhubung ke server';
    } finally {
        sendButton.disabled = false;
        status.textContent = 'Online';
        userInput.focus();
    }
}

// Fungsi untuk menambahkan pesan ke chat box
function addMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;

    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    // Format teks (support newline)
    contentDiv.innerHTML = text.replace(/\n/g, '<br>');
    
    messageDiv.appendChild(contentDiv);
    chatBox.appendChild(messageDiv);
    
    // Auto scroll ke bawah
    chatBox.scrollTop = chatBox.scrollHeight;
}